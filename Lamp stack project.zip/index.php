<?php

    include("connect.php");



    if (isset($_POST['btn']))

    {

      $q="select * from stock_list";

      $query=mysqli_query($con,$q);

    }

else

{

      $q= "select * from stock_list";

      $query=mysqli_query($con,$q);

    }

?>



<html>

    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <title>View List</title>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

        <link rel="stylesheet" href="style.css">

    </head>

    <body>

        <div class="container mt-5">

            <!-- top -->

            <div class="row">

                <div class="col-lg-8">

                    <h1>View Stock List</h1>

                    <a href="add.php">Add Item</a>

                </div>

            </div>

           

            <div class="row mt-4">

               

             <?php

                  while ($qq=mysqli_fetch_array($query))

                  {

                 

             ?>


                <div class="col-lg-4">

                    <div class="card">

                        <div class="card-body">

                          <h5 class="card-title">Stock Name : <?php echo $qq['content']; ?></h5>

                          <h6 class="card-subtitle mb-2 text-muted">Stock Price : <?php echo $qq['stocks']; ?></h6>


                          <a href="delete.php?id=<?php echo $qq['id']; ?>" class="card-link">Delete</a>

              		 	 <a href="update.php?id=<?php echo $qq['id']; ?>" class="card-link">Update</a>

                        </div>



                      </div><br>

                </div>

                <?php

                  }

                ?>

               
            </div>

        </div>

    </body>

</html>
