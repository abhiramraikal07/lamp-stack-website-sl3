<?php
    $con=mysqli_connect("localhost","abhi","Siddu@17" ,"CRYPTO");
    if(!$con)
    {
    die("cannot connect to server");
    }
?>
  
