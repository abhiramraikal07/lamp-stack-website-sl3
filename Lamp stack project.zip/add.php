<html>

    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <title>Add Stock</title>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

        <link rel="stylesheet" href="style.css">

    </head>

    <body>

        <div class="container mt-5">

            <h1>Add Stock Details</h1>

            <form action="add.php" method="POST">
                <div class="form-group">

                    <label>Stock Name</label>

                    <input type="text" class="form-control" placeholder="stock_name" name="stkid"/>

                </div>

                <div class="form-group">

                    <label>Stock Price</label>

                    <input type="text" class="form-control" placeholder="stock_price" name="price"/>

                </div>

            
                <div class="form-group">

                    <input type="submit" value="Add" class="btn btn-danger" name="btn">

                </div>

            </form>

        </div>

<?php

           if(isset($_POST["btn"]))

           {
               include("connect.php");

               $stock_name=$_POST['stkid'];

               $price=$_POST['price'];


               $q="insert into stock_list(content,stocks)values('$stock_name','$price')";

               mysqli_query($con,$q);
               header("location:index.php");




           }

         ?>



    </body>

</html>
