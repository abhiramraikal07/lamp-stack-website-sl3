<?php
	include("connect.php");
	$id = $_GET['id'];
	$q = "delete from stock_list where id = $id ";
	mysqli_query($con,$q);
	header("location:index.php");
	
?>
