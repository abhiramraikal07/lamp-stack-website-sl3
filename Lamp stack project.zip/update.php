<?php
    include("connect.php");
    if(isset($_POST['btn']))
    {
        $stock_name=$_POST['stkid'];
        $price=$_POST['price'];
        $id = $_GET['id'];
        $q= "update stock_list set content='$stock_name', stocks=$price where id=$id";
        $query=mysqli_query($con,$q);
        header('location:index.php');
    } 
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Update List</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container mt-5">
            <h1>Update Stock List</h1>
            <form method="post">
                <div class="form-group">
                    <label>Stock Name</label>
                    <input type="text" class="form-control" name="stkid" placeholder="stock_name" value="<?php echo $res['content'];?>"/>
                </div>
                <div class="form-group">
                    <label>Price</label>
                    <input type="text" class="form-control" name="price" placeholder="stock_price" value="<?php echo $res['stocks'];?>"/>
                </div>

                <div class="form-group">
                    <input type="submit" value="Update" name="btn" class="btn btn-danger">
                </div>
            </form>
        </div>
    </body> 
</html>
